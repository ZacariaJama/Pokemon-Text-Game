package com.example.pokemon;
//--------------------------------------------

//Zacaria Jama
//Pokemon Project
//  This program is a text-only recreation of the famous Pokemon Trading Card Game. It will recreate the "fun" and "real time stratey" involved in the actual card game by including features such as energy and special moves. This game will force you to choose a team of only 4 pokemon from a premade array of 28. You will then have to battle your way through the other 24 Pokemon you didn't think were cool enough to bring with you. When you win (because you probably used Gyarados) you will earn the title, Trainer Supreme! (We are still trying to find away to sell this to kids without getting sued)

import java.io.*;
import java.util.*;

class PokemonArena {
    private static ArrayList<Pokemon> allPoke = new ArrayList<Pokemon>();//This is where all the pokemon objects made from the info in the text files are stored.
    private static ArrayList<Pokemon> myTeam = new ArrayList<Pokemon>();//This is where the pokemon YOU choose are stored.
    private static ArrayList<Pokemon> enemy = new ArrayList<Pokemon>();// This is where the left over, not picked Pokemon will be (except the will be in a random order each time).
    private static ArrayList<Pokemon> activePoke = new ArrayList<Pokemon>();//This is where the Pokemon being used by the player ill be at any given time.

    public static void main(String[]args){
        try{
            Scanner kb = new Scanner(System.in);
            Scanner pokeFile = new Scanner(new BufferedReader(new FileReader("C:\\Users\\zjama\\JAVA PROGRAMS\\Pokemon\\src\\main\\java\\com\\example\\pokemon\\pokemon.txt")));//This reads the text file with all the information to make Pokemon objects
            while (pokeFile.hasNext()) {
                allPoke.add(new Pokemon(pokeFile.nextLine()));
            }
            for(int j=1;j<allPoke.size()+1;j++){
                System.out.print(j+". "+allPoke.get(j-1).name()+"\n");//This prints out all the pokemon in a list with a number beside each one.
            }
            System.out.println("Please input a number corrisponding to the pokemon you would like to use:");
            pickATeam();//This runs a method that lets the user pick a team in case it wasn't clear enough.
            System.out.println("Welcome to the Pokemon Battle Arena! Your first fight begins now!");
            for(int p=0;p<24;p++){//this randomizes all the pokemon from allPoke, and puts them in an "enemy" array. This allows the user to fight their opponent Pokémon in a random order every time they play
                int randomPoke = randInt(0,allPoke.size()-1);
                enemy.add(allPoke.get(randomPoke));
                allPoke.remove(randomPoke);//this guarantee the same pokemon wont be added to the "enemy" array twice, so it wont be fought twice in the same tournament.
            }
            System.out.print("Your first opponent is "+enemy.get(0).justName()+"! \n");//The first enemy in the enemy array will always be the only one in combat.
            System.out.println("Choose your pokemon:");
            while(true){
                int choose = kb.nextInt();
                if(choose == 1){
                    activePoke.add(myTeam.get(0));//whichever Pokémon the user picks, it will be moved to "activePoke". Only the Pokemon the user is using will ever be in "activePoke".
                    myTeam.remove(0);//The pokemon being used is removed from the list so when it comes time to switch out, the active Pokémon can't switch into itself.
                    System.out.println("I choose you, "+activePoke.get(0).justName()+"!");
                    break;
                }
                else if(choose == 2){
                    activePoke.add(myTeam.get(1));
                    myTeam.remove(1);
                    System.out.println("I choose you, "+activePoke.get(0).justName()+"!");
                    break;
                }
                else if(choose == 3){
                    activePoke.add(myTeam.get(2));
                    myTeam.remove(2);
                    System.out.println("I choose you, "+activePoke.get(0).justName()+"!");
                    break;
                }
                else if(choose == 4){
                    activePoke.add(myTeam.get(3));
                    myTeam.remove(3);
                    System.out.println("I choose you, "+activePoke.get(0).justName()+"!");
                    break;
                }
                else{
                    System.out.println("Invalid input.");
                }
            }
            while(true){
                System.out.println("What will you do?");
                System.out.println("1. Attack \n"+"2. Retreat \n"+"3. Pass \n"+"Click any other button to quit the game");
                //This shows the user their three options.
                int move = kb.nextInt();
                if(move == 1){
                    activePoke.get(0).attack(enemy.get(0));
                    if(enemy.size()<=0){//since each enemy Pokémon is removed from the "enemy" array when defeated, then all that is needed to see when the player has won is to see when the "enemy" list is empty.
                        System.out.println("CONGRATULATIONS!!!!!!! YOU BEAT EACH AND EVERY POKEMON! We happily bestow upon you the title of \n\n --------------------TRAINER SUPREME--------------------");
                        break;
                    }
                    if(enemy.get(0).hp()<=0){
                        for(int p=0;p<myTeam.size();p++) {//This loop will give every Pokemon in your team an energy reset and a 20 health boost at the end of every battle.
                            myTeam.get(p).energyReset();
                            myTeam.get(p).plus20hp();
                        }
                        activePoke.get(0).energyReset();
                        activePoke.get(0).plus20hp();
                        enemy.remove(0);
                        enemy.get(0).energyReset();//this resets the enrgy for the new enmy Pokémon so they always have 50 energy to start. A fair game
                        System.out.println("Your new opponent is "+enemy.get(0).justName()+"! Good luck! \n");
                    }
                    if(activePoke.get(0).hp() <= 0 ){
                        System.out.println("Your "+activePoke.get(0).justName()+" has fainted! They are no longer usable! \n");
                        retreat();//This forces you to switch out your pokemon after it has been knocked out.
                        for(int p=0;p<myTeam.size();p++) {//At the end of every turn all Pokémon gain 10 energy.
                            myTeam.get(p).plus10energy();
                        }
                        activePoke.get(0).plus10energy();
                        enemy.get(0).plus10energy();
                        myTeam.remove(myTeam.size()-1);//Since any pokemon switched out automatically goes to last slot on the users team, This allows me to delete the fainted Pokémon from the game completey.
                    }
                    System.out.println("Click enter to continue:");
                    kb.nextLine();//This line makes the user click enter to continue. This stops the screen anytime something happens, letting the user digest what happened. the user then clicks enter to continue the game.
                }
                else if(move == 2){
                    retreat();
                    activePoke.get(0).enemyAttack(enemy.get(0));//This is the method found in the Pokemon class that allows the enemy to attack. This lets the enemy punish the user for retreating.
                    for(int p=0;p<myTeam.size();p++) {
                        myTeam.get(p).plus10energy();
                    }
                    activePoke.get(0).plus10energy();
                    enemy.get(0).plus10energy();
                    if(activePoke.get(0).hp() <= 0 ){
                        System.out.println("Your "+activePoke.get(0).justName()+" has fainted! They are no longer usable! \n");
                        retreat();
                        myTeam.remove(myTeam.size()-1);
                    }
                    System.out.println("Click enter to continue:");
                    kb.nextLine();
                }
                else if(move == 3){
                    System.out.println("Your "+activePoke.get(0).justName()+" chose to do nothing.");
                    activePoke.get(0).enemyAttack(enemy.get(0));
                    for(int p=0;p<myTeam.size();p++) {
                        myTeam.get(p).plus10energy();
                    }
                    activePoke.get(0).plus10energy();
                    enemy.get(0).plus10energy();
                    if(activePoke.get(0).hp() <= 0 ){
                        System.out.println("Your "+activePoke.get(0).justName()+" has fainted! They are no longer usable! \n");
                        retreat();
                        myTeam.remove(myTeam.size()-1);
                    }
                    System.out.println("Click enter to continue:");
                    kb.nextLine();
                }
                else{
                    System.out.println("Invalid input.");
                    break;
                }
                kb.nextLine();
            }


        }
        catch(IOException ex){//This stops the program from crashing in the event that a "pokemon.txt" file can't be found or accessed.
            System.out.println("Ummm......... Where's 'pokemon.txt'?");
        }

    }
    public static int randInt(int low, int high){//This is a method that returns a random number from "low" to "high".
        return (int)(Math.random()*(high-low + 1)+low);
    }
    public static void pickATeam(){
        Scanner kb = new Scanner(System.in);
        while(true){//a while loop forces the user to keep picking until a valid team has been chosen
            int ally1 = kb.nextInt();
            if(ally1<=allPoke.size()){
                myTeam.add(allPoke.get(ally1-1));
                System.out.println("You chose "+allPoke.get(ally1-1).name()+". \n");
                allPoke.remove(ally1-1);//The pokemon chosen is removed from the allPoke array so it can't be picked again and so that none of the enemys be the same pokemon.
                break;
            }
            else{
                System.out.println("Invalid input. Please input a number corresponding to the pokemon you would like to use:");//so the actually pick a valid pokemon.
            }
        }
        while(true){
            for(int j=1;j<allPoke.size()+1;j++){
                System.out.print(j+". "+allPoke.get(j-1).name()+"\n");//reprints a modified list of options without any of the prviosly chosen pokemon.
            }
            int ally2 = kb.nextInt();
            if(ally2<=allPoke.size()){
                myTeam.add(allPoke.get(ally2-1));
                System.out.println("You chose "+allPoke.get(ally2-1).name()+". \n");
                allPoke.remove(ally2-1);
                break;
            }
            else{
                System.out.println("Invalid input. Please input a number corresponding to the pokemon you would like to use:");
            }
        }
        while(true){
            for(int j=1;j<allPoke.size()+1;j++){
                System.out.print(j+". "+allPoke.get(j-1).name()+"\n");
            }
            int ally3 = kb.nextInt();
            if(ally3<=allPoke.size()){
                myTeam.add(allPoke.get(ally3-1));
                System.out.println("You chose "+allPoke.get(ally3-1).name()+". \n");
                allPoke.remove(ally3-1);
                break;
            }
            else{
                System.out.println("Invalid input. Please input a number corresponding to the pokemon you would like to use:");
            }
        }
        while(true){
            for(int j=1;j<allPoke.size()+1;j++){
                System.out.print(j+". "+allPoke.get(j-1).name()+"\n");
            }
            int ally4 = kb.nextInt();
            if(ally4<=allPoke.size()){
                myTeam.add(allPoke.get(ally4-1));
                System.out.println("You chose "+allPoke.get(ally4-1).name()+". \n");
                System.out.println("This is your team. Good Luck, future champ! \n\n"+"1. "+myTeam.get(0).name()+"\n"+"2. "+myTeam.get(1).name()+"\n"+"3. "+myTeam.get(2).name()+"\n"+"4. "+myTeam.get(3).name()+"\n");
                allPoke.remove(ally4-1);
                break;
            }
            else{
                System.out.println("Invalid input. Please input a number corisponding to the pokemon you would like to use:");
            }
        }
    }
    public static void retreat(){
        Scanner kb = new Scanner(System.in);
        System.out.println("Who would you like to use?");
        for(int i=0;i<myTeam.size();i++){
            int j = i+1;
            System.out.println(j+". "+myTeam.get(i).name()+"\thp: "+myTeam.get(i).hp());
        }
        int rechoose = kb.nextInt();
        if(rechoose>myTeam.size()){//so the user doesn't break my game.
            System.out.println("Invalid input.");
        }
        else{
            myTeam.add(activePoke.get(0));// the active pokemon is added to the end of the team.
            activePoke.remove(0);// the active pokemon is taken out of "activePoke" since they will no longer be used.
            activePoke.add(myTeam.get(rechoose-1));
            myTeam.remove(rechoose-1);
            System.out.println("You switched out your active pokemon and swiched in "+activePoke.get(0).justName()+". \n");
        }
    }
}