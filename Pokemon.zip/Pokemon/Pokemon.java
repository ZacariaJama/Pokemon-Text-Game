package com.example.pokemon;//Zacaria Jama
import java.io.*;
import java.util.*;

public class Pokemon {
    private String name;
    private int hp;
    private int baseHp;
    private String type;
    private String resist;
    private String weak;
    private int numOfAttacks;
    private String attackName1,attackName2,attackName3;
    private int cost1,cost2,cost3;
    private int dmg1,dmg2,dmg3;
    private int basedmg1,basedmg2,basedmg3;
    private String special1,special2,special3;
    private int energy = 50;
    private int energy2 = 50;
    private int x = randInt(0,1);

    public Pokemon(String info){//This will create the Pokemon objects be spliting up the information given and assigning variables to them.
        String [] stats = info.split(",");
        name = stats[0];
        hp = Integer.parseInt(stats[1]);
        baseHp = Integer.parseInt(stats[1]);
        type = stats[2];
        resist = stats[3];
        weak = stats[4];
        numOfAttacks = Integer.parseInt(stats[5]);
        if(numOfAttacks == 1){
            attackName1 = stats[6];
            cost1 = Integer.parseInt(stats[7]);
            dmg1 = Integer.parseInt(stats[8]);
            basedmg1 = Integer.parseInt(stats[8]);
            special1 = stats[9];
        }
        if(numOfAttacks == 2){
            attackName1 = stats[6];
            cost1 = Integer.parseInt(stats[7]);
            dmg1 = Integer.parseInt(stats[8]);
            basedmg1 = Integer.parseInt(stats[8]);
            special1 = stats[9];
            attackName2 = stats[10];
            cost2 = Integer.parseInt(stats[11]);
            dmg2 = Integer.parseInt(stats[12]);
            basedmg2 = Integer.parseInt(stats[12]);
            special2 = stats[13];
        }
        if(numOfAttacks == 3){
            attackName1 = stats[6];
            cost1 = Integer.parseInt(stats[7]);
            dmg1 = Integer.parseInt(stats[8]);
            basedmg1 = Integer.parseInt(stats[8]);
            special1 = stats[9];
            attackName2 = stats[10];
            cost2 = Integer.parseInt(stats[11]);
            dmg2 = Integer.parseInt(stats[12]);
            basedmg2 = Integer.parseInt(stats[12]);
            special2 = stats[13];
            attackName3 = stats[14];
            cost3 = Integer.parseInt(stats[15]);
            dmg3 = Integer.parseInt(stats[16]);
            basedmg3 = Integer.parseInt(stats[16]);
            special3 = stats[17];
        }

    }
    public String name(){
        return name+"\t\t\t\ttype: "+type;
    }//This prints out the information you'd expect from the method name when called.
    public String justName(){
        return name;
    }//This prints out the information you'd expect from the method name when called.
    public int hp(){
        return hp;
    }//This prints out the information you'd expect from the method name when called.
    public void attack(Pokemon enemy) {
        Scanner kb = new Scanner(System.in);
        System.out.println("Which move would " + name + " like to use? (Your " + name + " has " + energy + " energy left)");
        //based on the number of attacks a Pokemon has,a different menu will be displayed showing only the attacks they are allowed to use and information on those attacks.
        if (numOfAttacks == 1) {
            System.out.print("1. " + attackName1 + "\t\tDMG: " + dmg1 + "\t\tEnergyCost: " + cost1);
            if(!special1.equals("")){//only shows the special effect of a move if the move has one.
                System.out.println("\t\tSpecialEffect: "+special1);
            }
            else{System.out.println();}
        } else if (numOfAttacks == 2) {
            System.out.print("1. " + attackName1 + "\t\t\tDMG: " + dmg1 + "\t\tEnergyCost: " + cost1);
            if(!special1.equals("")){//only shows the special effect of a move if the move has one.
                System.out.println("\t\tSpecialEffect: "+special1);
            }
            else{System.out.println();}
            System.out.print("2. " + attackName2 + "\t\t\tDMG: " + dmg2 + "\t\tEnergyCost: " + cost2);
            if(!special2.equals("")){
                System.out.println("\t\tSpecialEffect: "+special2);
            }
            else{System.out.println();}
        } else if (numOfAttacks == 3) {
            System.out.print("1. " + attackName1 + "\t\t\tDMG: " + dmg1 + "\t\tEnergyCost: " + cost1);
            if(!special1.equals("")){//only shows the special effect of a move if the move has one.
                System.out.println("\t\tSpecialEffect: "+special1);
            }
            else{System.out.println();}
            System.out.print("2. " + attackName2 + "\t\t\tDMG: " + dmg2 + "\t\tEnergyCost: " + cost2);
            if(!special2.equals("")){
                System.out.println("\t\tSpecialEffect: "+special2);
            }
            else{System.out.println();}
            System.out.print("3. " + attackName3 + "\t\t\tDMG: " + dmg3 + "\t\tEnergyCost: " + cost3);
            if(!special3.equals("")){
                System.out.println("\t\tSpecialEffect: "+special3);
            }
            else{System.out.println();}
        }
        int yourAttack = kb.nextInt();
        turnSwitch(x);//since x is a random private variable, this randomizes who attacks first in the battles. After that, the turns just alternate, as the method name suggests.
        if (yourAttack <= numOfAttacks) {//So players stop breaking my games.
            if (yourAttack == 1 && energy >= cost1) {//as long as the player has enough energy to use a move, the move will be used.
                special(enemy, attackName1, dmg1, cost1, special1, x);//This is where the attacking happens.
            } else if (yourAttack == 2 && energy >= cost2) {
                special(enemy, attackName2, dmg2, cost2, special2, x);
            } else if (yourAttack == 3 && energy >= cost3) {
                special(enemy, attackName3, dmg3, cost3, special3, x);
            } else {
                System.out.println("You do not have enough energy!");
            }
        }
        else{System.out.println("Invalid input");}
    }
    public void enemyAttack(Pokemon enemy) {
        String attackName = "";
        int cost = 0;
        int dmg = 0;
        String special = "";
        int notEnoughEnergy = 0;//This variable is a counter. It gets +1 every time the for loop runs and there is a move that the enemy pokemon has that the enemy pokemon doesn't have the energy for.
        for(int i=0;i<enemy.numOfAttacks;i++){
            if(energy2<cost1){
                notEnoughEnergy+=1;
            }
            if(energy2<cost2 && enemy.numOfAttacks == 2){
                notEnoughEnergy+=1;
            }
            if(energy2<cost2 && enemy.numOfAttacks == 3){
                notEnoughEnergy+=1;
            }
            if(energy2<cost3 && enemy.numOfAttacks == 3){
                notEnoughEnergy+=1;
            }
        }
        if(notEnoughEnergy<(enemy.numOfAttacks)*(enemy.numOfAttacks)){//If the enemy pokemn does not have the energy for any of it's moves, than the notEnoughEnergy variable will be equal to the numOfAttacks squared.
            while (true) {
                int randMove = randInt(0, numOfAttacks);//Now that we know that the enemy pokemon has enough energy to attack, we have to make sure it uses a valid move it has the energy for.
                if (randMove == 1) {
                    attackName = enemy.attackName1;
                    cost = enemy.cost1;
                    dmg = enemy.dmg1;
                    special = enemy.special1;
                    if(cost<=energy2){// This makes it so that the enemy pokemon will only use the move it has the energy for. if this move is not it, randMove randomly chooses another option.
                        enemySpecial(enemy, attackName, dmg, cost, special);//This method launches the enemy's attack.
                        plus10energyenemy();
                        break;
                    }
                } else if (randMove == 2) {
                    attackName = enemy.attackName2;
                    cost = enemy.cost2;
                    dmg = enemy.dmg2;
                    special = enemy.special2;
                    if(cost<=energy2){// This makes it so that the enemy pokemon will only use the move it has the energy for. if this move is not it, randMove randomly chooses another option.
                        enemySpecial(enemy, attackName, dmg, cost, special);
                        plus10energyenemy();
                        break;
                    }
                } else if (randMove == 3) {
                    attackName = enemy.attackName3;
                    cost = enemy.cost3;
                    dmg = enemy.dmg3;
                    special = enemy.special3;
                    if(cost<=energy2){// This makes it so that the enemy pokemon will only use the move it has the energy for. if this move is not it, randMove randomly chooses another option.
                        enemySpecial(enemy, attackName, dmg, cost, special);
                        plus10energyenemy();
                        break;
                    }
                }
            }
        }
        else{
            System.out.println("The enemy " + enemy.name + " did not have enough energy to attack! \n");
            plus10energyenemy();
        }
    }
    //These are self-explanatory.
    public void plus10energy(){
        if(energy<50){
            energy+=10;
        }
    }
    public void plus10energyenemy(){
        if(energy2<50){
            energy2+=10;
        }
    }
    public void energyReset(){
        energy =50;
    }
    public void plus20hp() {
        hp += 20;
        if(hp>baseHp){
            int extra = hp-baseHp;
            hp-=extra;
        }
    }
    public int turnSwitch(int x){
        if(x==1){
            x=0;
            return x;
        }
        else if(x==0){
            x=1;
            return x;
        }
        return x;
    }
    public int typing(Pokemon enemy,int dmg){//These methods return a modified dmg value based on whether or not the move used was "super effective" or "not very effective" or neither.
        if(type.equals(enemy.weak)){
            dmg+=20;
        }
        if(type.equals(enemy.resist)){
            dmg-=20;
        }
        if(dmg<0){dmg=0;}
        return dmg;
    }
    public int enemytyping(Pokemon enemy,int dmg){
        if(enemy.type.equals(resist)){
            dmg-=20;
        }
        if(enemy.type.equals(weak)){
            dmg+=20;
        }
        if(dmg<0){dmg=0;}
        return dmg;
    }
    public void printtyping(Pokemon enemy){//These methods print out whether the move used was "super effective" or "not very effective" or neither.
        if(type.equals(enemy.resist)){
            System.out.println("It was not very effective...");
        }
        if(type.equals(enemy.weak)){
            System.out.println("It was super effective!");
        }
    }
    public void printenemytyping(Pokemon enemy){
        if(enemy.type.equals(resist)){
            System.out.println("It was not very effective...");
        }
        if(enemy.type.equals(weak)){
            System.out.println("It was super effective!");
        }
    }
    public void special(Pokemon enemy,String attackName,int dmg,int cost,String special,int x){
        if(x==1) {//the determines who is moving first on a turn, so if the user goes first (x==1), then this happens and vis versa.
            if (special.equals("stun")) {
                int n = randInt(0, 1);//creates a 50/50
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);//I could have used "x -= y" instead of "x= x-y", i just chose not to.
                energy -= cost;//this subtracts the moves cost from your energy.
                printtyping(enemy);
                if (n == 0) {
                    if (enemy.hp > 0) {
                        System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                        System.out.println("You failed to stun them!");
                        enemyAttack(enemy);
                    }
                    if (enemy.hp <= 0) {
                        dmg1 = basedmg1;//this resets the dmg of everyone on the failed after an opponent faints in case anyone was disabled that battle.
                        dmg2 = basedmg2;
                        dmg3 = basedmg3;
                        enemy.dmg1 = enemy.basedmg1;
                        enemy.dmg2 = enemy.basedmg2;
                        enemy.dmg3 = enemy.basedmg3;
                        System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                    }
                } else if (n == 1) {
                    if (enemy.hp > 0) {
                        System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                        System.out.println("Your " + name + " stunned the opponent Pokémon! They are unable to attack this turn!");
                        //to stun the opponent and stop them from attacking, I didn't call "enemyAttack". Rocket science, I know.
                    }
                    if (enemy.hp <= 0) {
                        dmg1 = basedmg1;
                        dmg2 = basedmg2;
                        dmg3 = basedmg3;
                        enemy.dmg1 = enemy.basedmg1;
                        enemy.dmg2 = enemy.basedmg2;
                        enemy.dmg3 = enemy.basedmg3;
                        System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                    }
                }
            } else if (special.equals("disable")) {
                int n = randInt(0, 1);
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                printtyping(enemy);
                if (enemy.hp > 0) {
                    if (n == 0) {
                        enemy.dmg1 -= 10;//disabling subtracts 10dmg from all of the targets attacks. This will be reset at the end of a battle.
                        enemy.dmg2 -= 10;
                        enemy.dmg3 -= 10;
                        System.out.println("You disabled the opponent! They will do 10 less damage from now on!");
                        enemyAttack(enemy);
                    }
                    if (n == 1) {
                        System.out.println("You failed to disable the opponent!");
                        enemyAttack(enemy);
                    }
                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                }
                else if (enemy.hp <= 0) {
                    dmg1 = basedmg1;
                    dmg2 = basedmg2;
                    dmg3 = basedmg3;
                    enemy.dmg1 = enemy.basedmg1;
                    enemy.dmg2 = enemy.basedmg2;
                    enemy.dmg3 = enemy.basedmg3;
                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                }
            } else if (special.equals("recharge")) {
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                if (energy < 30) {///it's just recharging energy. if the amount of energy is 30 or more, than i make it 50.
                    energy += 20;
                    System.out.println("Your Pokemon has recharged some of it's energy! (pokemon can not have more than 50 energy)");
                } else {
                    energy = 50;
                    System.out.println("Your Pokemon has recharged some of it's energy! (pokemon can not have more than 50 energy)");
                }
                enemyAttack(enemy);
            } else if (special.equals("wild storm")) {
                int m = randInt(0, 1);
                if (m == 0) {
                    System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                    enemy.hp = enemy.hp - typing(enemy, dmg);
                    energy -= cost;
                    printtyping(enemy);
                    if(enemy.hp<=0){
                        dmg1 = basedmg1;
                        dmg2 = basedmg2;
                        dmg3 = basedmg3;
                        enemy.dmg1 = enemy.basedmg1;
                        enemy.dmg2 = enemy.basedmg2;
                        enemy.dmg3 = enemy.basedmg3;
                        System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                    }
                    if (enemy.hp > 0) {
                        System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                        while (true) {//Since has a 50% chance of hitting, and another 50% of hitting over and over again, a while loop is best.
                            int n = randInt(0, 1);
                            if (n == 0) {
                                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                                enemy.hp = enemy.hp - typing(enemy, dmg);//as long as n keeps being zero, this attack keeps happening.
                                if (enemy.hp > 0) {
                                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " extra hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                                }
                                if (enemy.hp <= 0) {
                                    dmg1 = basedmg1;
                                    dmg2 = basedmg2;
                                    dmg3 = basedmg3;
                                    enemy.dmg1 = enemy.basedmg1;
                                    enemy.dmg2 = enemy.basedmg2;
                                    enemy.dmg3 = enemy.basedmg3;
                                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                                    break;
                                }
                            }
                            if (n == 1) {
                                //If n==1, then the combo end there and the loop is broken.
                                enemyAttack(enemy);
                                break;
                            }
                        }
                    }
                }
                if (m == 1) {//If you don't even hit the first time, you "miss".
                    System.out.println("You missed!");
                    enemyAttack(enemy);
                }
            } else if (special.equals("wild card")) {// the less fun wild charge. It is the same as wild charge with a 50% chance of hitting, but that's it. Only one hit.
                int m = randInt(0, 1);
                if (m == 0) {//If i hit
                    System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                    enemy.hp = enemy.hp - typing(enemy, dmg);
                    energy -= cost;
                    printtyping(enemy);
                    if (enemy.hp > 0) {
                        System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                        enemyAttack(enemy);
                    }
                    if (enemy.hp <= 0) {
                        dmg1 = basedmg1;
                        dmg2 = basedmg2;
                        dmg3 = basedmg3;
                        enemy.dmg1 = enemy.basedmg1;
                        enemy.dmg2 = enemy.basedmg2;
                        enemy.dmg3 = enemy.basedmg3;
                        System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                    }
                }
                if (m == 1) {//If I don't
                    System.out.println("You missed!");
                    enemyAttack(enemy);
                }
            } else {//If the attack being does not have any special effects, then this just lets a turn play out normally, with the user attacking normally.
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                printtyping(enemy);
                if (enemy.hp > 0) {
                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                    enemyAttack(enemy);
                }
                if (enemy.hp <= 0) {
                    dmg1 = basedmg1;
                    dmg2 = basedmg2;
                    dmg3 = basedmg3;
                    enemy.dmg1 = enemy.basedmg1;
                    enemy.dmg2 = enemy.basedmg2;
                    enemy.dmg3 = enemy.basedmg3;
                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                }
            }
        }
        if(x==0){//This is when the enemy goes fisrt. It's the same as when the user goes first with very minor changes.
            if (special.equals("stun")) {// Stun can no longer happen, since you are going AFTER the opponent already attacks, so the users "stun" effect is basically ignored.
                enemyAttack(enemy);
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                printtyping(enemy);
                if (enemy.hp > 0) {
                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                    System.out.println("You were too slow to stun them!");
                }
                if (enemy.hp <= 0) {
                    dmg1 = basedmg1;
                    dmg2 = basedmg2;
                    dmg3 = basedmg3;
                    enemy.dmg1 = enemy.basedmg1;
                    enemy.dmg2 = enemy.basedmg2;
                    enemy.dmg3 = enemy.basedmg3;
                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                }
            } else if (special.equals("disable")) {
                int n = randInt(0, 1);
                enemyAttack(enemy);//The same thing as normal disable except now you're attack and effect goes off After the opponent attacks. This is the same for all the effects following this one.
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                printtyping(enemy);
                if (enemy.hp > 0) {
                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left.");
                    if (n == 0) {
                        enemy.dmg1 -= 10;
                        enemy.dmg2 -= 10;
                        enemy.dmg3 -= 10;
                        System.out.println("You disabled the opponent! They will do 10 less damage from now on!");
                    }
                    if (n == 1) {
                        System.out.println("You failed to disable the opponent!");
                    }
                }
                if (enemy.hp <= 0) {
                    dmg1 = basedmg1;
                    dmg2 = basedmg2;
                    dmg3 = basedmg3;
                    enemy.dmg1 = enemy.basedmg1;
                    enemy.dmg2 = enemy.basedmg2;
                    enemy.dmg3 = enemy.basedmg3;
                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                }
            } else if (special.equals("recharge")) {
                enemyAttack(enemy);
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                if (energy < 30) {
                    energy += 20;
                    System.out.println("Your Pokemon has recharged some of it's energy! (pokemon can not have more than 50 energy)");
                } else {
                    System.out.println(name + " used " + attackName + ".");
                    energy = 50;
                    System.out.println("Your Pokemon has recharged some of it's energy! (pokemon can not have more than 50 energy)");
                }
            } else if (special.equals("wild storm")) {
                int m = randInt(0, 1);
                if (m == 0) {
                    enemyAttack(enemy);
                    System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                    enemy.hp = enemy.hp - typing(enemy, dmg);
                    energy -= cost;
                    printtyping(enemy);
                    if (enemy.hp > 0) {
                        System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                        while (true) {
                            int n = randInt(0, 1);
                            if (n == 0) {
                                System.out.println(name + " used " + attackName + " again!");
                                enemy.hp = enemy.hp - typing(enemy, dmg);
                                if (enemy.hp > 0) {
                                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " extra hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                                }
                                if (enemy.hp <= 0) {
                                    dmg1 = basedmg1;
                                    dmg2 = basedmg2;
                                    dmg3 = basedmg3;
                                    enemy.dmg1 = enemy.basedmg1;
                                    enemy.dmg2 = enemy.basedmg2;
                                    enemy.dmg3 = enemy.basedmg3;
                                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                                    break;
                                }
                            }
                            if (n == 1) {
                                enemyAttack(enemy);
                                break;
                            }
                        }
                    }
                }
                if (m == 1) {
                    enemyAttack(enemy);
                    System.out.println("You missed!");
                }
            } else if (special.equals("wild card")) {
                int m = randInt(0, 1);
                if (m == 0) {
                    enemyAttack(enemy);
                    System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                    enemy.hp = enemy.hp - typing(enemy, dmg);
                    energy -= cost;
                    printtyping(enemy);
                    if (enemy.hp > 0) {
                        System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left. \n");
                    }
                    if (enemy.hp <= 0) {
                        dmg1 = basedmg1;
                        dmg2 = basedmg2;
                        dmg3 = basedmg3;
                        enemy.dmg1 = enemy.basedmg1;
                        enemy.dmg2 = enemy.basedmg2;
                        enemy.dmg3 = enemy.basedmg3;
                        System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                    }
                }
                if (m == 1) {
                    enemyAttack(enemy);
                    System.out.println("You missed!");
                }
            } else {
                enemyAttack(enemy);
                System.out.println(name + " used " + attackName + " on " + enemy.name + ".");
                enemy.hp = enemy.hp - typing(enemy, dmg);
                energy -= cost;
                printtyping(enemy);
                if (enemy.hp > 0) {
                    System.out.println(enemy.name + " lost " + typing(enemy, dmg) + " hp! " + enemy.name + " has " + enemy.hp + " hp left.\n");
                }
                if (enemy.hp <= 0) {
                    dmg1 = basedmg1;
                    dmg2 = basedmg2;
                    dmg3 = basedmg3;
                    enemy.dmg1 = enemy.basedmg1;
                    enemy.dmg2 = enemy.basedmg2;
                    enemy.dmg3 = enemy.basedmg3;
                    System.out.println("Your " + name + " defeated " + enemy.name + "! \n");
                }
            }
        }
    }
    public void enemySpecial(Pokemon enemy,String attackName,int dmg,int cost,String special){//This method is similar to "special" in the sense that it allows the enemy pokemon to fight using special effects if they can. The only difference is that there is no calling of the "enemyAttack" method since "enemySpecial" is used to how the enemy attacks in "enemyAttack".
        if(special.equals("disable")){
            int n = randInt(0, 1);
            System.out.println(enemy.name + " used " + attackName + " on " + name + ".");
            hp = hp - enemytyping(enemy, dmg);
            energy2 -= cost;
            printenemytyping(enemy);
            if (hp > 0) {
                System.out.println(name + " lost " + enemytyping(enemy, dmg) + " hp! " + name + " has " + hp + " hp left. \n");
                if (n == 0) {
                    dmg1 -= 10;
                    dmg2 -= 10;
                    dmg3 -= 10;
                    System.out.println("The opponent disabled you! You will do 10 less damage from now on! (until battle is over)");
                }
                if (n == 1) {
                    System.out.println("The opponent failed to disable you!");
                }
            }
            else if (hp <= 0) {
                dmg1 = basedmg1;
                dmg2 = basedmg2;
                dmg3 = basedmg3;
                System.out.println("Your " + name + " was defeated! \n");
            }
        }
        else if (special.equals("recharge")) {
            System.out.println(enemy.name + " used " + attackName + " on " + name + ".");
            hp = hp - enemytyping(enemy, dmg);
            energy2 -= cost;
            if (energy2 < 30) {
                energy2 += 20;
                System.out.println("The opponent has recharged some of it's energy! (pokemon can not have more than 50 energy)");
            } else {
                energy2 = 50;
                System.out.println("The opponent has recharged some of it's energy! (pokemon can not have more than 50 energy)");
            }
        }
        else if (special.equals("wild storm")) {
            int m = randInt(0, 1);
            if (m == 0) {
                System.out.println(enemy.name + " used " + attackName + " on " + name + ".");
                hp = hp - enemytyping(enemy, dmg);
                energy2 -= cost;
                printenemytyping(enemy);
                if (hp > 0) {
                    System.out.println(name + " lost " + enemytyping(enemy, dmg) + " extra hp! " + name + " has " + enemy.hp + " hp left. \n");
                    while (true) {
                        int n = randInt(0, 1);
                        if (n == 0) {
                            System.out.println(enemy.name + " used " + attackName + " on " + name + ".");
                            hp = hp - enemytyping(enemy, dmg);
                            printenemytyping(enemy);
                            if (hp > 0) {
                                System.out.println(name + " lost " + enemytyping(enemy, dmg) + " extra hp! " + name + " has " + hp + " hp left. \n");
                            }
                            if(hp<=0){
                                dmg1 = basedmg1;
                                dmg2 = basedmg2;
                                dmg3 = basedmg3;
                                System.out.println("Your " + name + " was defeated! \n");
                                break;
                            }
                        }
                        if (n == 1) {
                            break;
                        }
                    }
                }
            }
            if (m == 1) {
                System.out.println("The enemy missed!");
            }
        }
        else if (special.equals("wild card")) {
            int m = randInt(0, 1);
            if (m == 0) {
                System.out.println(enemy.name + " used " + attackName + " on " + name + ".");
                hp = hp - enemytyping(enemy, dmg);
                energy2 -= cost;
                printenemytyping(enemy);
                if (enemy.hp > 0) {
                    System.out.println(name + " lost " + enemytyping(enemy, dmg) + " hp! " + name + " has " + hp + " hp left. \n");
                }
                if (enemy.hp <= 0) {
                    System.out.println("Your " + name + " was defeated! \n");
                }
            }
            if (m == 1) {
                System.out.println("The enemy missed!");
            }
        }
        else{
            System.out.println(enemy.name + " used " + attackName + " on " + name + ".");
            hp = hp - enemytyping(enemy, dmg);
            energy2 -= cost;
            printenemytyping(enemy);
            if (hp > 0) {
                System.out.println(name + " lost " + enemytyping(enemy, dmg) + " hp! " + name + " has " + hp + " hp left. \n");
            }
            if (hp <= 0) {
                System.out.println("Your " + name + " was defeated! \n");
            }
        }
    }
    public static int randInt(int low, int high){
        return (int)(Math.random()*(high-low + 1)+low);
    }
}